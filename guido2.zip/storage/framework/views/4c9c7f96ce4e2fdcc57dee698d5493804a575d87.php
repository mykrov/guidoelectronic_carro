<div id="quickview-wrapper">
        <!-- Modal -->
        <div class="modal fade" id="productModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <!-- modal-content-start-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-product">
                            <!-- product-images -->
                            
                            <div class="product-images">
                                <div class="main-image images">
                                    <img id="modal-imagen" alt="" src="<?php echo e(asset('assets/themebasic/images/product/')); ?>">
                                </div>
                            </div>
                            
                            <!-- product-images -->
                            <!-- product-info -->
                            <div class="product-info">
                                <h1 id="modal-nombre"></h1>
                                <div class="price-box-3">
                                    <div class="s-price-box">
                                        <span id="modal-precio" class="normal-price"></span>
                                    </div>
                                </div>
                                <a href="shop-grid.html" class="see-all">Mirar todas las caracteristicas</a>
                                <div class="quick-add-to-cart">
                                    <form method="post" class="cart">
                                        <div class="numbers-row">
                                            <input type="number" id="french-hens" value="1">
                                        </div>
                                        <button  type="submit">Añadir</button>
                                    </form>
                                </div>
                                <div  class="quick-desc">
                                    <h1>Codigo deProducto:</h1>
                                    <h2 id="modal-codigo"></h2>
                                </div>
                                <div class="social-sharing">
                                    <div class="widget widget_socialsharing_widget">
                                        <h3 class="widget-title-modal">Compartir este producto</h3>
                                        <ul class="social-icons">
                                            <li><a target="_blank" title="Facebook" href="#" class="facebook social-icon"><i class="fa fa-facebook"></i></a>
                                            </li>
                                            <li><a target="_blank" title="Twitter" href="#" class="twitter social-icon"><i class="fa fa-twitter"></i></a>
                                            </li>
                                            <li><a target="_blank" title="Pinterest" href="#" class="pinterest social-icon"><i class="fa fa-pinterest"></i></a>
                                            </li>
                                            <li><a target="_blank" title="Google +" href="#" class="gplus social-icon"><i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li><a target="_blank" title="LinkedIn" href="#" class="linkedin social-icon"><i class="fa fa-linkedin"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- product-info -->
                        </div>
                        <!-- modal-product -->
                    </div>
                    <!-- modal-body -->
                </div>
                <!-- modal-content -->
            </div>
            <!-- modal-dialog -->
        </div>
        <!-- END Modal -->
    </div><?php /**PATH C:\laragon\www\surtioffice\resources\views/modal.blade.php ENDPATH**/ ?>