<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\guido\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>