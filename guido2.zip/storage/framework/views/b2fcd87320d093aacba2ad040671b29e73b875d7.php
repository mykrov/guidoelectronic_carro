<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Inicio</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800i" rel="stylesheet">
        
        <!-- favicon icon -->
        <link rel="shortcut icon" type="images/png" href="<?php echo e(asset('assets/themebasic/images/favicon.ico')); ?>">
        
		<!-- all css here -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/themebasic/style.css')); ?>">
		<!-- modernizr css -->
    <script src="<?php echo e(asset('assets/themebasic/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!-- Add your site or application content here -->
        <!--Start-Preloader-area-->
        <div class="preloader">
            <div class="loading-center">
                <div class="loading-center-absolute">
                    <div class="object object_one home-4"></div>
                    <div class="object object_two home-4"></div>
                    <div class="object object_three home-4"></div>
                </div>
            </div>
        </div>
        <!--end-Preloader-area-->
        <!--header-area-start-->
        <!--Start-main-wrapper-->
        <div class="page-4">
            <!--Start-Header-area-->
            <header>
                <div class="header-top-wrap home-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="header-top-left">
                                    <!--Start-Header-language-->
                                    <div class="dropdown top-language-wrap"> <a role="button" data-toggle="dropdown" data-target="#" class="top-language dropdown-toggle" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/flag/es.png')); ?>" alt="language"> Español <span class="caret"></span> </a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li role="presentation"><a role="menuitem" href="#"><img src="<?php echo e(asset('assets/themebasic/images/flag/es.png')); ?>" alt="language"> Español </a></li>
                                            <li role="presentation"><a role="menuitem" href="#"><img src="<?php echo e(asset('assets/themebasic/images/flag/e.png')); ?>" alt="language"> English </a></li>
                                        </ul>
                                    </div>
                                    <!--End-Header-language-->
                                    <!--Start-Header-currency-->
                                    <div class="dropdown top-currency-wrap"> <a role="button" data-toggle="dropdown" data-target="#" class="top-currency dropdown-toggle" href="#"><span class="usd-icon"><i class="fa fa-usd"></i></span> USD <span class="caret"></span></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li role="presentation"><a role="menuitem" href="#"> $ - Dolar Americano</a></li>
                                            <li role="presentation"><a role="menuitem" href="#"> € - Euro </a></li>
                                        </ul>
                                    </div>
                                    <!--End-Header-currency-->
                                    <!--Start-welcome-message-->
                                    <div class="welcome-mg hidden-xs"><span>Bienvenidos!</span></div>
                                    <!--End-welcome-message--> 
                                </div>
                            </div>
                            <!-- Start-Header-links -->
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="header-top-right">
                                    <div class="top-link-wrap">
                                        <div class="single-link">
                                            <div class="my-account"><a href="my-account.html"><span class="">Mi cuenta</span></a></div>
                                            <div class="wishlist"><a href="wishlist.html"><span class="">Deseos</span></a></div>
                                            <div class="check"><a href="checkout.html"><span class="">Checkout</span></a></div>
                                            <div class="login"><a href="login.html"><span  class="">Iniciar Sesión</span></a></div>
                                        </div>
                                    </div>
									
                                </div>

                            </div>
                             <!-- End-Header-links -->
                        </div>
                    </div>
                </div>
                <!--Start-header-mid-area-->
                <div class="header-mid-wrap home-4">
                    <div class="container">
                        <div class="header-mid-content">
                            <div class="row">
                                <!--Start-logo-area-->
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="header-logo">
                                        <a href="index.html"><img src="<?php echo e(asset('assets/themebasic/images/logo/1.png')); ?>" alt="Mt-Shop"></a>
                                    </div>
                                </div>
                                <!--End-logo-area-->
                                <!--Start-gategory-searchbox-->
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div id="search-category-wrap">
                                        <form class="header-search-box" action="#" method="post">
                                            <div class="search-cat">
                                                <select class="category-items" name="category">
                                                    <option>Todas</option>
                                                    <option>Archivos</option>
                                                    <option>Consumo</option>
                                                    <option>Descartables</option>
                                                    <option>Energía</option>
                                                    <option>Escritura</option>
                                                    <option>Insumos de Limpieza</option>
                                                    <option>Papel Higiénico</option>
                                                    <option>Papelería</option>
                                                    <option>Seguridad</option>
                                                    <option>Suministros de Tecnología</option>
													<option>Útiles de Oficina</option>
                                                    <option>Útiles Escolares</option>
                                                </select>
                                            </div>
                                            <input type="search" placeholder="Buscar aquí..." id="text-search" name="search">
                                            <button id="btn-search-category" type="submit">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <!--End-gategory-searchbox-->
                                <!--Start-cart-wrap-->
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <ul class="header-cart-wrap">
                                        <li><a class="cart" href="#">2 items</a>
                                            <div class="mini-cart-content">
                                                <div class="cart-products-list">
                                                    <div class="sing-cart-pro">
                                                        <div class="cart-image">
                                                            <a href="#"><img src="<?php echo e(asset('assets/themebasic/images/product/4.jpg')); ?>" alt=""></a>
                                                        </div>
                                                        <div class="cart-product-info">
                                                            <a href="#" class="product-name"> Ejemplo Producto </a>
                                                            <div class="cart-price">
                                                                <span class="quantity"><strong> 1 x</strong></span>
                                                                <span class="p-price">$110.00</span>
                                                            </div>
                                                            <a class="edit-pro" title="edit"><i class="fa fa-pencil-square-o"></i></a>
                                                            <a class="remove-pro" title="remove"><i class="fa fa-times"></i></a>
                                                        </div>
                                                    </div>
                                                    <div class="sing-cart-pro">
                                                        <div class="cart-image">
                                                            <a href="#"><img src="<?php echo e(asset('assets/themebasic/images/product/1.jpg')); ?>" alt=""></a>
                                                        </div>
                                                        <div class="cart-product-info">
                                                            <a href="#" class="product-name">Ejemplo Producto </a>
                                                            <div class="cart-price">
                                                                <span class="quantity"><strong> 1 x</strong></span>
                                                                <span class="p-price">$150.00</span>
                                                            </div>
                                                            <a class="edit-pro" title="edit"><i class="fa fa-pencil-square-o"></i></a>
                                                            <a class="remove-pro" title="remove"><i class="fa fa-times"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="cart-price-list">
                                                    <p class="price-amount"><span class="cart-subtotal">SUBTotal :</span> <span>$260.00</span> </p>
                                                    <div class="cart-checkout">
                                                        <a href="checkout.html">Checkout</a>
                                                    </div>
                                                    <div class="view-cart">
                                                        <a href="shopping-cart.html">Ver Orden</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!--End-cart-wrap-->
                            </div>
                        </div>    
                    </div>
                </div>
                <!--End-header-mid-area-->
                <!--Start-Mainmenu-area -->
                <div class="mainmenu-area home-4 hidden-sm hidden-xs">
                    <div id="sticker"> 
                        <div class="container">
                            <div class="row">   
                                <div class="col-lg-12 col-md-12 hidden-sm hidden-xs">
                                    <div class="log-small"><a class="logo" href="index.html"><img alt="Mt-Shop" src="<?php echo e(asset('assets/themebasic/images/logo/s.png')); ?>"></a></div>
                                    <div class="mainmenu home-4">
                                        <nav>
                                            <ul id="nav">
                                                <li ><a href="index.html">Inicio</a>
                                                </li>
												<li><a href="about-us.html">Quienes Somos</a></li>
												<li><a href="my-account.html">Mi Cuenta</a></li>
                                                <li class="angle-down"><a href="#">Categorias</a>
                                                    <ul class="sub-menu">
                                                        <li><a class="tecnologia" href="#">Suministros de Tecnología</a></li>
                                                        <li><a class="archivos" href="#">Archivos y Registros</a></li>
                                                        <li><a class="consumo" href="#">Consumo</a></li>
                                                        <li><a class="descartables" href="#">Descartables</a></li>
                                                        <li><a class="energia" href="#">Energía e Iluminación</a></li>
                                                        <li><a class="escritura" href="#">Escritura</a></li>
                                                        <li><a class="limpieza" href="#">Insumos de Limpieza</a></li>
                                                        <li><a class="higienico" href="#">Papel Higiénico</a></li>
                                                        <li><a class="papeleria" href="#">Papelería</a></li>
                                                        <li><a class="seguridad" href="#">Seguridad Industrial</a></li>
                                                        <li><a class="oficina" href="#">Útiles de Oficina</a></li>
                                                        <li><a class="escolares" href="#">Útiles Escolares</a></li>
                                                    </ul>
                                                </li>
												<li><a href="wishlist.html">Mis Deseos</a></li>
												<li><a href="how-buy.html">Como Comprar</a></li>
                                                <li><a href="contact-us.html">Contacto</a></li>
                                            </ul>
                                        </nav>
                                    </div>        
                                </div>
                            </div>
                        </div>
                    </div>      
                </div>
                <!--End-Mainmenu-area-->
                <!--Start-Mobile-Menu-Area -->
                <div class="mobile-menu-area visible-sm visible-xs">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="mobile-menu">
                                    <nav id="dropdown">
                                        <ul>
											    <li ><a href="index.html">Inicio</a>
                                                </li>
												<li><a href="about-us.html">Quienes Somos</a></li>
												<li><a href="my-account.html">Mi Cuenta</a></li>
												<li><a href="#">Categorias</a>
													<ul>
                                                        <li><a class="tecnologia" href="#">Suministros de Tecnología</a></li>
                                                        <li><a class="archivos" href="#">Archivos y Registros</a></li>
                                                        <li><a class="consumo" href="#">Consumo</a></li>
                                                        <li><a class="descartables" href="#">Descartables</a></li>
                                                        <li><a class="energia" href="#">Energía e Iluminación</a></li>
                                                        <li><a class="escritura" href="#">Escritura</a></li>
                                                        <li><a class="limpieza" href="#">Insumos de Limpieza</a></li>
                                                        <li><a class="higienico" href="#">Papel Higiénico</a></li>
                                                        <li><a class="papeleria" href="#">Papelería</a></li>
                                                        <li><a class="seguridad" href="#">Seguridad Industrial</a></li>
                                                        <li><a class="oficina" href="#">Útiles de Oficina</a></li>
                                                        <li><a class="escolares" href="#">Útiles Escolares</a></li>
													</ul>
												</li>
												<li><a href="wishlist.html">Mis Deseos</a></li>
												<li><a href="how-buy.html">Como Comprar</a></li>
                                                <li><a href="contact-us.html">Contacto</a></li>
                                        </ul>
                                    </nav>
                                </div>					
                            </div>
                        </div>
                    </div>
                </div>
                <!--End-Mobile-Menu-Area -->
            </header>
            <!--End-Header-area-->
			
			
            <!-- Start-slider-->
            <section class="slider-area home-1">
                            <div class="preview-1 home-4">
                                <div id="ensign-nivoslider" class="slides">	
                                    <img src="<?php echo e(asset('assets/themebasic/images/slider/1.jpg')); ?>" alt="" title="#slider-direction-1" />
                                    <img src="<?php echo e(asset('assets/themebasic/images/slider/2.jpg')); ?>" alt="" title="#slider-direction-2" />
                                </div>
                                <!-- direction 1 -->
                                <div id="slider-direction-1" class="t-cn slider-direction slider-one">
                                    <div class="slider-progress"></div>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 text-right">
												<div class="slider-content">
													<!-- layer 1 -->
													<div class="layer-1-1">
														<h2 class="title1 wow bounceInLeft" data-wow-duration="0.5s" data-wow-delay=".8s">Promocion <span class="h-color">3X2</span></h2>
													</div>
													<!-- layer 2 -->
													<div class="layer-1-2">
														<p class="title2">
															<span class="fashion-1 wow bounceInLeft" data-wow-duration="0.5s" data-wow-delay="1s"><i class="fa fa-paperclip" style="font-size:40px;"></i>
															</span>
														</p>
													</div>
													<!-- layer 3 -->
													<div class="layer-1-3 hidden-xs">
														<p class="title3 wow bounceInLeft" data-wow-duration="0.5s" data-wow-delay="1.5s" >Productos destacados por su asombrosa capacidad.</p>
													</div>
													<!-- layer 4 -->
													<div class="layer-1-4">
														<a class="shop-n wow zoomInUp" data-wow-duration="0.5s" data-wow-delay="2s" href="#">Comprar Ahora</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- direction 2 -->
                                <div id="slider-direction-2" class="slider-direction slider-two">
                                    <div class="slider-progress"></div>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 text-left">
												<div class="slider-content">
													<!-- layer 1 -->
													<div class="layer-1-1">
														<h2 class="title1 wow bounceInRight" data-wow-duration="0.5s" data-wow-delay=".8s">Descuentos <span class="h-color">30%</span></h2>
													</div>
													<!-- layer 2 -->
													<div class="layer-1-2">
														<p class="title2">
															<span class="fashion-1 fashion-2 wow bounceInRight" data-wow-duration="0.5s" data-wow-delay="1s"><i class="fa fa-paperclip" style="font-size:40px;"></i>
															</span>
														</p>
													</div>
													<!-- layer 3 -->
													<div class="layer-1-3 layer-2-3 hidden-xs">
														<p class="title3  wow bounceInRight" data-wow-duration="0.5s" data-wow-delay="1.5s" >Productos resistentes con un estilo moderno.</p>
													</div>
													<!-- layer 4 -->
													<div class="layer-2-4">
														<a class="shop-n wow zoomInUp" data-wow-duration="0.5s" data-wow-delay="2s" href="#">Comprar ahora</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                   
                
            </section>
            <!-- End-slider-->
			
			   
			
            <!--Start-latest-products-wrap-->
            <div class="latest-products-wrap home-4 padding-t">
					<div class="container">
						<div class="row">
				        <!--start-categry-area-->
                        <div class="col-lg-3 col-md-3">
                            <div class="category-main-wrap home-4 hidden-sm hidden-xs">
                                <div class="category-title"><h3>Categorias</h3></div>
                                    <div class="cat-single-wrap">
                                        <ul class="nav">
                                            <li>
												<a class="tecnologia" href="#">SUMINISTROS DE TECNOLOGÍA</a>
												<div class="single-wrap tablet">
													<div class="cat-wrap">
														<ul class="nav">
															<li><a href="#">dell</a></li>
															<li><a href="#">nokia</a></li>
															<li><a href="#">canon</a></li>
															<li><a href="#">Sony</a></li>
															<li><a href="#">samsung</a></li>
															<li><a href="#">asus</a></li>
															<li><a href="#">hp</a></li>
															<li><a href="#">nikon</a></li>
															<li><a href="#">apple</a></li>
															<li><a href="#">toshiba</a></li>
														</ul>
													</div>
												</div>
											</li>
                                        <li>
                                            <a class="archivos" href="#">Archivos y Registros</a>
											<div class="single-wrap tablet">
                                                <div class="cat-wrap">
                                                    <ul class="nav">
                                                        <li><a href="#">dell</a></li>
                                                        <li><a href="#">nokia</a></li>
                                                        <li><a href="#">canon</a></li>
                                                        <li><a href="#">Sony</a></li>
                                                        <li><a href="#">samsung</a></li>
                                                        <li><a href="#">asus</a></li>
                                                        <li><a href="#">hp</a></li>
                                                        <li><a href="#">nikon</a></li>
                                                        <li><a href="#">apple</a></li>
                                                        <li><a href="#">toshiba</a></li>
                                                    </ul>
                                                </div>
                                            </div>

                                        </li>
                                        <li>
                                            <a class="consumo" href="#">Consumo</a>
											<div class="single-wrap tablet">
                                                <div class="cat-wrap">
                                                    <ul class="nav">
                                                        <li><a href="#">dell</a></li>
                                                        <li><a href="#">nokia</a></li>
                                                        <li><a href="#">canon</a></li>
                                                        <li><a href="#">Sony</a></li>
                                                        <li><a href="#">samsung</a></li>
                                                        <li><a href="#">asus</a></li>
                                                        <li><a href="#">hp</a></li>
                                                        <li><a href="#">nikon</a></li>
                                                        <li><a href="#">apple</a></li>
                                                        <li><a href="#">toshiba</a></li>
                                                    </ul>
                                                </div>
                                            </div>

                                        </li>
                                        <li>
                                            <a class="descartables" href="#">Descartables</a>
                                            <div class="single-wrap tablet">
                                                <div class="cat-wrap">
                                                    <ul class="nav">
                                                        <li><a href="#">dell</a></li>
                                                        <li><a href="#">nokia</a></li>
                                                        <li><a href="#">canon</a></li>
                                                        <li><a href="#">Sony</a></li>
                                                        <li><a href="#">samsung</a></li>
                                                        <li><a href="#">asus</a></li>
                                                        <li><a href="#">hp</a></li>
                                                        <li><a href="#">nikon</a></li>
                                                        <li><a href="#">apple</a></li>
                                                        <li><a href="#">toshiba</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <a class="energia" href="#">Energía e Iluminación</a>
                                            <div class="single-wrap tablet">
                                                <div class="cat-wrap">
                                                    <ul class="nav">
                                                        <li><a href="#">dell</a></li>
                                                        <li><a href="#">nokia</a></li>
                                                        <li><a href="#">canon</a></li>
                                                        <li><a href="#">Sony</a></li>
                                                        <li><a href="#">samsung</a></li>
                                                        <li><a href="#">asus</a></li>
                                                        <li><a href="#">hp</a></li>
                                                        <li><a href="#">nikon</a></li>
                                                        <li><a href="#">apple</a></li>
                                                        <li><a href="#">toshiba</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
										<li class="cat-none"><a class="escritura" href="#">Escritura</a></li>
                                        <li class="cat-none"><a class="limpieza" href="#">Insumos de Limpieza</a></li>    
                                        <li class="cat-none"><a class="higienico" href="#">Papel Higiénico</a></li>
                                        <li class="more-view"><a class="papeleria" href="#">Papelería</a></li>
                                        <li class="more-view"><a class="seguridad" href="#">Seguridad Industrial</a></li>
										<li class="more-view"><a class="oficina" href="#">Útiles de Oficina</a></li>
										<li class="more-view"><a class="escolares" href="#">Útiles Escolares</a></li>
                                        <li class="view-more"><a href="#">Más categorías</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!--end-category-area-->
						
                
					<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                    <div class="latest-content text-center">
                        <div class="section-heading">
                            <h3><span class="h-color">Productos</span> Nuevos</h3>
                        </div>
                    </div>
                    <div class="row">
                        <div class="featured-carousel2 indicator">
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product sold-out">
                                <div class="sale">-5%</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/29.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-link"> 
                                            <a href="#">
                                                <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                            </a>
                                            <a data-toggle="modal" data-target="#productModal" href="#">
                                                <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                            </a>
                                            <a href="#">
                                                <div><i class="fa fa-random"></i><span>Añadir</span></div>
                                            </a>
                                        </div>
                                        <div class="sold-text">
                                            <span style="line-height: 40px;">Agotado</span>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                            <div class="pro-rating">
                                                <ul>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                </ul>
                                            </div>
                                            <div class="pro-price">
                                                <span class="price-text">Precio:</span>
                                                <span class="normal-price">$200.00</span>
                                                <span class="old-price"><del>$220.00</del></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-5%</div>
                                <div class="new">NUEVO</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/27.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-link"> 
                                            <a href="#">
                                                <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                            </a>
                                            <a data-toggle="modal" data-target="#productModal" href="#">
                                                <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                            </a>
                                            <a href="#">
                                                <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                            </a>
                                        </div>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                            <div class="pro-rating">
                                                <ul>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                </ul>
                                            </div>
                                            <div class="pro-price">
                                                <span class="price-text">Precio:</span>
                                                <span class="normal-price">$200.00</span>
                                                <span class="old-price"><del>$220.00</del></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-5%</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/28.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-link"> 
                                            <a href="#">
                                                <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                            </a>
                                            <a data-toggle="modal" data-target="#productModal" href="#">
                                                <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                            </a>
                                            <a href="#">
                                                <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                            </a>
                                        </div>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                            <div class="pro-rating">
                                                <ul>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                </ul>
                                            </div>
                                            <div class="pro-price">
                                                <span class="price-text">Precio:</span>
                                                <span class="normal-price">$170.00</span>
                                                <span class="old-price"><del>$200.00</del></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="new">NUEVO</div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-link"> 
                                            <a href="#">
                                                <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                            </a>
                                            <a data-toggle="modal" data-target="#productModal" href="#">
                                                <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                            </a>
                                            <a href="#">
                                                <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                            </a>
                                        </div>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                            <div class="pro-rating">
                                                <ul>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                </ul>
                                            </div>
                                            <div class="pro-price">
                                                <span class="price-text">Precio:</span>
                                                <span class="normal-price">$200.00</span>
                                                <span class="old-price"><del>$220.00</del></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-10%</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/32.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-link"> 
                                            <a href="#">
                                                <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                            </a>
                                            <a data-toggle="modal" data-target="#productModal" href="#">
                                                <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                            </a>
                                            <a href="#">
                                                <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                            </a>
                                        </div>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                            <div class="pro-rating">
                                                <ul>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                </ul>
                                            </div>
                                            <div class="pro-price">
                                                <span class="price-text">Precio:</span>
                                                <span class="normal-price">$200.00</span>
                                                <span class="old-price"><del>$220.00</del></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-10%</div>
                                <div class="new">NUEVO</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/30.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-link"> 
                                            <a href="#">
                                                <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                            </a>
                                            <a data-toggle="modal" data-target="#productModal" href="#">
                                                <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                            </a>
                                            <a href="#">
                                                <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                            </a>
                                        </div>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                            <div class="pro-rating">
                                                <ul>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                </ul>
                                            </div>
                                            <div class="pro-price">
                                                <span class="price-text">Precio:</span>
                                                <span class="normal-price">$280.00</span>
                                                <span class="old-price"><del>$300.00</del></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-20%</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/31.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-link"> 
                                            <a href="#">
                                                <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                            </a>
                                            <a data-toggle="modal" data-target="#productModal" href="#">
                                                <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                            </a>
                                            <a href="#">
                                                <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                            </a>
                                        </div>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                            <div class="pro-rating">
                                                <ul>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star"></i></li>
                                                    <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                </ul>
                                            </div>
                                            <div class="pro-price">
                                                <span class="price-text">Precio:</span>
                                                <span class="normal-price">$200.00</span>
                                                <span class="old-price"><del>$220.00</del></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                        </div>
                    </div>
					</div>
					</div>
                </div>
            </div>
            <!--End-latest-products-wrap-->
            <!-- Start-banner-area-->
            <div class="banner-area padding-t home-4">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                            <div class="single-banner banner-m-b">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/14.jpg')); ?>" /></a>
                            </div>
                            <div class="single-banner banner-r-b">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/15.jpg')); ?>" /></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="single-banner banner-r-b">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/16.jpg')); ?>" /></a>
                            </div>
                        </div>
                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-banner four">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/13.jpg')); ?>" /></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End-banner-area-->
            <!-- Start-featured-area-->
            <div class="featured-product-wrap home-4 padding-t">
                <div class="container">				   
                    <!-- section-heading start -->
                    <div class="section-heading">
                        <h3><span class="h-color">PRODUCTOS</span> DESTACADOS</h3>
                    </div>
                    <!-- section-heading end -->
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="features-tab">
                              <!-- Nav tabs -->
                                <ul class="nav nav-tabs" role="tablist">
                                    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Tecnologías</a></li>
                                    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Descartables</a></li>
                                    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Papelería</a></li>
                                    <li role="presentation"><a href="#section" aria-controls="messages" role="tab" data-toggle="tab">Útiles Escolares</a></li>
                                </ul>
                                <!-- Tab panes -->
                                <div class="tab-content">
                                    <!--start-home-section-->
                                    <div role="tabpanel" class="tab-pane active" id="home">
                                        <div class="row">
                                            <div class="featured-carousel indicator">
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product sold-out">
                                                    <div class="sale">-5%</div>
                                                    <div class="new">NUEVO</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/26.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="sold-text">
                                                                <span style="line-height: 40px;">Agotado</span>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/31.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$130.00</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="upcoming-product featured-count">
                                                            <div data-countdown="2017/10/05"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">NUEVO</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/32.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$150.00</span>
                                                                    <span class="old-price"><del>$170.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="sale">-5%</div>
                                                    <div class="new">NUEVO</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/30.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$200.00</span>
                                                                    <span class="old-price"><del>$230.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/29.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">-5%</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                            </div>
                                        </div>
                                    </div>
                                    <!--end-home-section-->
                                    <!--start-profile-section-->
                                    <div role="tabpanel" class="tab-pane" id="profile">
                                        <div class="row">
                                            <div class="featured-carousel indicator">
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">-5%</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/27.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$120.00</span>
                                                                    <span class="old-price"><del>$140.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product sold-out">
                                                    <div class="sale">-5%</div>
                                                    <div class="new">NUEVO</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/28.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="sold-text">
                                                                <span style="line-height: 40px;">Agotado</span>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/30.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$300.00</span>
                                                                    <span class="old-price"><del>$320.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">NUEVO</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$150.00</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">NUEVO</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/32.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$140.00</span>
                                                                    <span class="old-price"><del>$170.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="sale">-5%</div>
                                                    <div class="new">NUEVO</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/26.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                            </div>
                                        </div>	
                                    </div>
                                    <!--end-profile-section-->
                                    <!--start-messages-section-->
                                    <div role="tabpanel" class="tab-pane" id="messages">
                                        <div class="row">
                                            <div class="featured-carousel indicator">
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="sale">-5%</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/28.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">-5%</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/32.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$200.00</span>
                                                                    <span class="old-price"><del>$220.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">NUEVO</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/31.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$180.00</span>
                                                                    <span class="old-price"><del>$210.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/30.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="sale">-5%</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/26.jpg')); ?> " alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$240.00</span>
                                                                    <span class="old-price"><del>$300.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                            </div>
                                        </div>	
                                    </div>
                                    <!--end-messages-section-->
                                    <!--start-section-section-->
                                    <div role="tabpanel" class="tab-pane" id="section">
                                        <div class="row">
                                            <div class="featured-carousel indicator">
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="sale">-5%</div>
                                                    <div class="new">NUEVO</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/29.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$90.00</span>
                                                                    <span class="old-price"><del>$100.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">NUEVO</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/30.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$200.00</span>
                                                                    <span class="old-price"><del>$220.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="new">-5%</div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/27.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$190.00</span>
                                                                    <span class="old-price"><del>$210.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/26.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$100.00</span>
                                                                    <span class="old-price"><del>$120.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                                <!-- Start-single-product -->
                                                <div class="col-lg-3">
                                                    <div class="single-product">
                                                    <div class="sale">-5%</div>
                                                    <div class="sale-border"></div>
                                                        <div class="product-img-wrap"> 
                                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                                            <div class="add-to-link"> 
                                                                <a href="#">
                                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                                </a>
                                                                <a data-toggle="modal" data-target="#productModal" href="#">
                                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                                </a>
                                                                <a href="#">
                                                                    <div><i class="fa fa-random"></i><span>Comparar</span></div>
                                                                </a>
                                                            </div>
                                                            <div class="add-to-cart">
                                                                <a href="#" title="add to cart">
                                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-center">
                                                            <div class="product-content">
                                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                                <div class="pro-rating">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="pro-price">
                                                                    <span class="price-text">Precio:</span>
                                                                    <span class="normal-price">$140.00</span>
                                                                    <span class="old-price"><del>$170.00</del></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End-single-product -->
                                            </div>
                                        </div>	
                                    </div>
                                    <!--end-section-section-->
                                </div>
                            </div>				
                        </div>
						
                    </div>
				</div>
            </div>
            <!--End-featured-area-->
            <!--Satar-business-policy-wrap-->
            <div class="business-policy-wrap padding-t">
                <div class="container">
                    <div class="row">
                       <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap banner-r-b text-center">
                                <span><i class="fa fa-plane"></i></span>
                                <h4>Envios a todas las provincias<br> del Ecuador.</h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                        <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap banner-r-b text-center">
                                <span><i class="fa fa-life-ring"></i></span>
                                <h4>Soporte 24/7. Estamos en línea las 24 horas del día.</h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                        <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap banner-r-b text-center">
                                <span><i class="fa fa-money"></i></span>
                                <h4>Todos los productos tienen garantia al 100%!</h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                        <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap text-center">
                                <span><i class="fa fa-clock-o"></i></span>
                                <h4>En oficina, atendemos desde las 9:00AM - <br>Cierre: 6:00PM.</h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                    </div>
                </div>
            </div>
            <!--End-business-policy-wrap-->
            <!--Start-banner-area-->
            <div class="banner-area padding-t home-4 banner-dis">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                            <div class="single-banner banner-r-b">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/26.jpg')); ?>" /></a>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                            <div class="single-banner">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/17.jpg')); ?>" /></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End-banner-area-->
            <div class="clear"></div>
             <!--Start-top-catagories-wrap-->
            <div class="latest-products-wrap home-4 padding-t">
                <div class="container">
                    <!--start-top-categories-heading-->
                    <div class="latest-content text-center">
                        <div class="section-heading">
                            <h3><span class="h-color">Top</span> Categorias</h3>
                        </div>
                    </div>
                    <!--end-top-categories-heading-->
                    <div class="row">
                        <div class="featured-carousel indicator">
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-5%</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"><img src="<?php echo e(asset('assets/themebasic/images/product/26.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><span>Ver más</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Energía</h3></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-10%</div>
                                <div class="new">NUEVO</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><span>Ver más</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Insumos de Limpieza</h3></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-5%</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/27.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><span>Ver más</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Suministros de Tecnología</h3></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="new">NUEVO</div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/29.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><span>Ver más</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Descartable</h3></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-10%</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/34.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><span>Ver más</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Consumo</h3></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                            <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="single-product">
                                <div class="sale">-30%</div>
                                <div class="new">Nuevo</div>
                                <div class="sale-border"></div>
                                    <div class="product-img-wrap"> 
                                        <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/35.jpg')); ?>" alt="product-image" /></a>
                                        <div class="add-to-cart">
                                            <a href="#" title="add to cart">
                                                <div><span>Ver más</span></div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-info text-center">
                                        <div class="product-content">
                                            <a href="#"><h3 class="pro-name">Archivos</h3></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End-single-product -->
                        </div>
                    </div>
                </div>
            </div>
            <!--End-top-categories-wrap-->
            <!--Start-latest-testimonials-->    
            <div class="latest-testimonial-wrap home-4">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                            <!--start-testimonial-heading-->
                            <div class="testimonial-heading home-4">
                                <div class="section-heading">
                                    <h3><span class="h-color">Últimos</span> Testimonios</h3>
                                </div>
                            </div>
                            <!--End-testimonial-heading-->
                        </div>
                    </div>
                </div>
                <div class="main-testimonial home-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="testimonial-carousel indicator">
                                    <!--single-testimonial-start-->
                                    <div class="single-testimonial">
                                        <div class="testimonial-img">
                                            <p><img src="<?php echo e(asset('assets/themebasic/images/testimonial/1.jpg')); ?>" alt=""></p>
                                        </div>
                                        <div class="testimonial-des home-1">
                                            <p>(Ejemplo 1) En esta tienda, siempre encuentro todo a menor precio y con excelente calidad.<br> Recomiendo siempre a mis trabajadores y amigos este sitio... </p>
                                        </div>
                                        <div class="testimonial-author">
                                            <h5>Lcdo Alberto Espinoza de los Monteros</h5>
                                        </div>
                                    </div>
                                    <!--single-testimonial-end-->
                                    <!--single-testimonial-start-->
                                    <div class="single-testimonial">
                                        <div class="testimonial-img">
                                            <p><img src="<?php echo e(asset('assets/themebasic/images/testimonial/2.jpg')); ?>" alt=""></p>
                                        </div>
                                        <div class="testimonial-des">
                                            <p>(Ejemplo 2) En esta tienda, siempre encuentro todo a menor precio y con excelente calidad.<br> Recomiendo siempre a mis trabajadores y amigos este sitio... </p>
                                        </div>
                                        <div class="testimonial-author">
                                            <h5>Lcdo Lenín Moreno</h5>
                                        </div>
                                    </div>
                                    <!--single-testimonial-end-->
                                    <!--single-testimonial-start-->
                                    <div class="single-testimonial">
                                        <div class="testimonial-img">
                                            <p><img src="<?php echo e(asset('assets/themebasic/images/testimonial/3.jpg')); ?>" alt=""></p>
                                        </div>
                                        <div class="testimonial-des">
                                            <p>(Ejemplo 3) En esta tienda, siempre encuentro todo a menor precio y con excelente calidad.<br> Recomiendo siempre a mis trabajadores y amigos este sitio... </p>
                                        </div>
                                        <div class="testimonial-author">
                                            <h5>Ing. Jhon Quispillo - Birobid</h5>
                                        </div>
                                    </div>
                                    <!--single-testimonial-end-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
            <!--End-latest-testimonials-->
            <!--Start-variety-products-wrap-->
            <div class="variety-products-wrap home-4 padding-t">
                <div class="container">
                    <div class="row">
                        <!--start-best-seller-product-->
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <div class="best-heading">
                                <div class="section-heading best-h">
                                    <h3><span class="h-color">Más</span> Vendidas</h3>
                                </div>
                            </div>
                            <div class="best-carousel">
                                <!--start-double-best-product-->
                                <div class="best-double-product">
                                    <!-- Start-single-product -->
                                    <div class="single-product margin-b">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/31.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                    <!-- Start-single-product -->
                                    <div class="single-product">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/28.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                </div>
                                <!--end-double-best-product-->
                                <!--start-double-best-product-->
                                <div class="best-double-product">
                                    <!-- Start-single-product -->
                                    <div class="single-product margin-b">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/30.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                    <!-- Start-single-product -->
                                    <div class="single-product">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/26.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                </div>
                                <!--end-double-best-product-->
                            </div>
                        </div>
                        <!--end-best-seller-product-->
                        <!--start-Top-rated-product-->
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 top-rated">
                            <div class="best-heading">
                                <div class="section-heading best-h">
                                    <h3><span class="h-color">Ventas</span> Recientes</h3>
                                </div>
                            </div>
                            <div class="best-carousel">
                                <!--start-double-best-product-->
                                <div class="best-double-product">
                                    <!-- Start-single-product -->
                                    <div class="single-product margin-b">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/27.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                    <!-- Start-single-product -->
                                    <div class="single-product">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/29.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                </div>
                                <!--end-double-best-product-->
                                <!--start-double-best-product-->
                                <div class="best-double-product">
                                    <!-- Start-single-product -->
                                    <div class="single-product margin-b">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                    <!-- Start-single-product -->
                                    <div class="single-product">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/32.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                </div>
                                <!--end-double-best-product-->
                            </div>
                        </div>
                        <!--end-Top-rated-product-->
                        <!--start-best-offer-product-->
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 best-off">
                            <div class="best-heading">
                                <div class="section-heading best-h">
                                    <h3><span class="h-color">Mejores</span> Ofertas</h3>
                                </div>
                            </div>
                            <div class="best-carousel">
                                <!--start-double-best-product-->
                                <div class="best-double-product">
                                    <!-- Start-single-product -->
                                    <div class="single-product margin-b">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/32.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                    <!-- Start-single-product -->
                                    <div class="single-product">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/33.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                </div>
                                <!--end-double-best-product-->
                                <!--start-double-best-product-->
                                <div class="best-double-product">
                                    <!-- Start-single-product -->
                                    <div class="single-product margin-b">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/26.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                    <!-- Start-single-product -->
                                    <div class="single-product">
                                        <div class="product-img-wrap best-s-w"> 
                                            <a class="product-img" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/product/30.jpg')); ?>" alt="product-image" /></a>
                                        </div>
                                        <div class="product-info best-s text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name">Ejemplo Producto</h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$140.00</span>
                                                    <span class="old-price"><del>$170.00</del></span>
                                                </div>
                                                <div class="add-to-cartbest">
                                                    <a href="#" title="add to cart">
                                                        <div><span>Añadir</span></div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End-single-product -->
                                </div>
                                <!--end-double-best-product-->
                            </div>
                        </div>
                        <!--end-best-offer-product-->
                    </div>
                </div>
            </div>
            <!--End-variety-products-wrap-->
            <!--Start-newsletter-wrap-->
            <div class="news-letter-wrap text-center home-4">
                <div class="container">
                    <div class="row">
                        <div class="news-subscribe">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="letter-text">
                                    <h3><span class="h-color">No</span> se pierda <br> <span><img src="<?php echo e(asset('assets/themebasic/images/newsletter/1.png')); ?>" alt=""></span></h3>
                                    <p>Suscribase a nuestro boletín semanal para recibir nuestros descuentos del <span class="h-color">30%</span> en su primera compra.</p>
                                </div>
                            </div>    
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="email-area">
                                    <form class="input-group" action="#" method="post">
                                        <span class="input-group-addon icon-envlop">
                                        <i class="fa fa-envelope-o"></i>
                                        </span>
                                        <input type="email" class="form-control form_text" placeholder="Ingresa tu email aquí">
                                        <input type="submit" class="submit" value="Enviar">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End-newsletter-wrap-->
            <!--Start-footer-wrap-->
            <footer class="footer-area">
                <div class="footer-top-area home-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-5 col-xs-12">
                                <div class="footer-logo">
                                    <a href="index.html"><img src="<?php echo e(asset('assets/themebasic/images/logo/1_white.png')); ?>" alt="Logo Demo"></a>
                                </div>
                                <!--footer-text-start-->
                                <div class="footer-top-content">
                                    <p class="des">empresa dedicada a la distribución y comercialización de suministros de oficina, aseo y limpieza a nivel nacional.</p>
                                    <div class="footer-read-more">
                                        <a href="#">Leer mas</a>
                                         <span><i class="fa fa-long-arrow-right"></i></span>
                                    </div>
                                </div>
                                <!--footer-text-end-->
                                <!--footer-link-area-start-->
                                <div class="social-icon">
                                    <h4>Síguenos</h4>
                                    <a class="faceb" href="#" title="Facebook"><i class="fa fa-facebook"></i></a>
                                     <a class="twitt" href="#" title="Twitter" ><i class="fa fa-twitter"></i></a>
                                    <a class="tumb" href="#" title="Tumblr"><i class="fa fa-tumblr"></i></a>
                                    <a class="google" href="#" title="Google-plus"><i class="fa fa-google-plus"></i></a>
                                    <a class="dribb" href="#" title="Dribbble"><i class="fa fa-dribbble"></i></a>
                                </div>
                                <!--footer-link-area-end-->
                            </div>
                            <!--footer-tag-area-start-->
                            <div class="tag-area">
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                    <h3 class="wedget-title">Últimos Tags</h3>
                                    <div class="footer-top-content">
                                        <ul>
                                            <li><a href="#">archivos</a></li>
                                            <li><a href="#">consumo</a></li>
                                            <li><a href="#">descartables</a></li>
                                            <li><a href="#">energía</a></li>
                                            <li><a href="#">escritura</a></li>
                                            <li><a href="#">insumos_de_limpieza</a></li>
                                            <li><a href="#">papelería</a></li>
                                            <li><a href="#">seguridad</a></li>
                                            <li><a href="#">suministros_de_tecnología</a></li>
                                            <li><a href="#">útiles_de_oficina</a></li>
                                            <li><a href="#">útiles_escolares</a></li>
                                        </ul>
                                        <div class="view-all-tag">
                                            <ul>
                                                <li><a href="#">Ver todos</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--footer-tag-area-end-->
                            <!--footer-account-area-start-->
                            <div class="footer-account-area footer-none">
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-12">
                                    <h3 class="wedget-title">Mi cuenta</h3>
                                    <div class="footer-top-content">
                                        <ul>
                                            <li><a href="my-account.html">Mi cuenta</a></li>
                                            <li><a href="#">Inicio Sesión</a></li>
                                            <li><a href="#">Mi carrito</a></li>
                                            <li><a href="#">Deseos</a></li>
                                            <li><a href="#">Ubicación</a></li>
                                            <li><a href="#">Politica de Privacidad</a></li>
                                            <li><a href="#">Descuentos</a></li>
                                            <li><a href="#">Contacto</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!--footer-account-area-end-->
                            <!--footer-contact-info-start-->
                            <div class="footer-contact-info">
                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                    <h3 class="wedget-title">Contactenos</h3>
                                    <div class="footer-contact">
                                        <p class="adress"><label>Dirección:</label><span class="ft-content">Km 11.5 Vía a Daule, Parque California 1, Bodega E-7, Guayaquil 090706, Ecuador.</span></p>
                                        <p class="phone"><label>Teléfono:</label><span class="ft-content phone-num"><span class="phone1">+593 98 205 9105</span><span class="phone2">+593 42 103 880</span></span></p>
                                        <p class="web"><label>Email:</label><span class="ft-content web-site"><a href="mailto: ventas@surtioffice.ec">ventas@surtioffice.ec</a></span></p>
                                    </div>
                                </div>
                            </div>
                            <!--footer-contact-info-end-->
                        </div>
                    </div>
                </div>
                <!--footer-top-area-end-->
                <!--footer-bottom-area-start-->
                <div class="footer-bottom-area home-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="copy-right">
                                    <span> Copyright &copy; Birobid. Todos los derechos reservados.</span>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="payment-area">
                                    <ul>
                                        <li><a title="Paypal" href="#"><img src="<?php echo e(asset('assets/themebasic/images/payment/1.png')); ?>" alt="Paypal"></a></li>
                                        <li><a title="Visa" href="#"><img src="<?php echo e(asset('assets/themebasic/images/payment/2.png')); ?>" alt="Visa"></a></li>
                                        <li><a title="Bank" href="#"><img src="<?php echo e(asset('assets/themebasic/images/payment/3.png')); ?>" alt="Bank"></a></li>
                                        <li class="hidden-xs"><a title="Mastercard" href="#"><img src="<?php echo e(asset('assets/themebasic/images/payment/4.png')); ?>" alt="Mastercard"></a></li>
                                        <li><a title="Discover" href="#"><img src="<?php echo e(asset('assets/themebasic/images/payment/5.png')); ?>" alt="Discover"></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--footer-bottom-area-end-->
            </footer>
            <!--End-footer-wrap-->
             
        </div>
        <!--End-main-wrapper-->
        <!-- Quickview-product-strat -->
        <div id="quickview-wrapper">
            <!-- Modal -->
            <div class="modal fade" id="productModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <!-- modal-content-start-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="modal-product">
                                <!-- product-images -->
								
                                <div class="product-images">
                                    <div class="main-image images">
                                        <img alt="" src="<?php echo e(asset('assets/themebasic/images/product/31.jpg')); ?>">
                                    </div>
                                </div>
								
                                <!-- product-images -->
                                <!-- product-info -->
                                <div class="product-info">
                                    <h1>Ejemplo Producto</h1>
                                    <div class="price-box-3">
                                        <div class="s-price-box">
                                            <span class="normal-price">$333.00</span>
                                        </div>
                                    </div>
                                    <a href="shop-grid.html" class="see-all">Mirar todas las caracteristicas</a>
                                    <div class="quick-add-to-cart">
                                        <form method="post" class="cart">
                                            <div class="numbers-row">
                                                <input type="number" id="french-hens" value="3">
                                            </div>
                                            <button  type="submit">Añadir</button>
                                        </form>
                                    </div>
                                    <div class="quick-desc">
                                        Texto de ejemplo.
                                    </div>
                                    <div class="social-sharing">
                                        <div class="widget widget_socialsharing_widget">
                                            <h3 class="widget-title-modal">Compartir este producto</h3>
                                            <ul class="social-icons">
                                                <li><a target="_blank" title="Facebook" href="#" class="facebook social-icon"><i class="fa fa-facebook"></i></a>
                                                </li>
                                                <li><a target="_blank" title="Twitter" href="#" class="twitter social-icon"><i class="fa fa-twitter"></i></a>
                                                </li>
                                                <li><a target="_blank" title="Pinterest" href="#" class="pinterest social-icon"><i class="fa fa-pinterest"></i></a>
                                                </li>
                                                <li><a target="_blank" title="Google +" href="#" class="gplus social-icon"><i class="fa fa-google-plus"></i></a>
                                                </li>
                                                <li><a target="_blank" title="LinkedIn" href="#" class="linkedin social-icon"><i class="fa fa-linkedin"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- product-info -->
                            </div>
                            <!-- modal-product -->
                        </div>
                        <!-- modal-body -->
                    </div>
                    <!-- modal-content -->
                </div>
                <!-- modal-dialog -->
            </div>
            <!-- END Modal -->
        </div>
        <!-- End quickview product -->

        
        
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="<?php echo e(asset('assets/themebasic/js/vendor/jquery-1.12.0.min.js')); ?>"></script>
		<!-- bootstrap js -->
        <script src="<?php echo e(asset('assets/themebasic/js/bootstrap.min.js')); ?>"></script>
		<!-- owl.carousel js -->
        <script src="<?php echo e(asset('assets/themebasic/js/owl.carousel.min.js')); ?>"></script>
		<!-- meanmenu.js -->
        <script src="<?php echo e(asset('assets/themebasic/js/jquery.meanmenu.js')); ?>"></script>
		<!-- nivo.slider.js -->
        <script src="<?php echo e(asset('assets/themebasic/lib/js/jquery.nivo.slider.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/themebasic/lib/home.js')); ?>" type="text/javascript"></script>
		<!-- jquery-ui js -->
        <script src="<?php echo e(asset('assets/themebasic/js/jquery-ui.min.js')); ?>"></script>
		<!-- scrollUp.min.js -->
        <script src="<?php echo e(asset('assets/themebasic/js/jquery.scrollUp.min.js')); ?>"></script>
		<!-- jquery.parallax.js -->
        <script src="<?php echo e(asset('assets/themebasic/js/jquery.parallax.js')); ?>"></script>
		<!-- sticky.js -->
        <script src="<?php echo e(asset('assets/themebasic/js/jquery.sticky.js')); ?>"></script>
        <!-- jquery.simpleGallery.min.js -->
        <script src="<?php echo e(asset('assets/themebasic/js/jquery.simpleGallery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/themebasic/js/jquery.simpleLens.min.js')); ?>"></script>
        <!-- countdown.min.js -->
        <script src="<?php echo e(asset('assets/themebasic/js/jquery.countdown.min.js')); ?>"></script>
		<!-- wow js -->
        <script src="<?php echo e(asset('assets/themebasic/js/wow.min.js')); ?>"></script>
		<!-- plugins js -->
        <script src="<?php echo e(asset('assets/themebasic/js/plugins.js')); ?>"></script>
		<!-- main js -->
        <script src="<?php echo e(asset('assets/themebasic/js/main.js')); ?>"></script>
    </body>
</html>     <?php /**PATH C:\laragon\www\surtioffice\resources\views/index.blade.php ENDPATH**/ ?>