<!doctype html>
<html class="no-js" lang="en">
    <?php $__env->startSection('head-meta'); ?>
        <?php echo $__env->make('head-meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php
            if (\Session::has('usuario-tipo')) {
                $tipo = \Session::get('usuario-tipo');

                if (trim($tipo) == 'CTB') {
                    $precioAc = 'precio2';
                } elseif (trim($tipo) == 'CTC') {
                    $precioAc = 'precio3';
                }elseif (trim($tipo) == 'CTD') {
                    $precioAc = 'precio4';
                }elseif (trim($tipo) == 'CTE') {
                    $precioAc = 'precio5';
                }elseif (trim($tipo) == 'CTA'){
                    $precioAc = 'precio';
                }
            } else {
                $precioAc='precio';
            }
        ?> 
    <?php echo $__env->yieldSection(); ?>
  
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!-- Add your site or application content here -->
        <!--Start-Preloader-area-->
        <div class="preloader">
            <div class="loading-center">
                <div class="loading-center-absolute">
                    <div class="object object_one home-4"></div>
                    <div class="object object_two home-4"></div>
                    <div class="object object_three home-4"></div>
                </div>
            </div>
        </div>
        <!--end-Preloader-area-->
        <!--header-area-start-->
        <!--Start-main-wrapper-->
        <div class="page-4">
            <?php $__env->startSection('header'); ?>
                <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <?php echo $__env->yieldSection(); ?>
            
            <?php $__env->startSection('slider'); ?>
                <?php echo $__env->make('slider-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <?php echo $__env->yieldSection(); ?>

            <!-- Start-slider-->
        
            <!-- End-slider-->
			
            <!--Start-latest-products-wrap-->
            <div class="latest-products-wrap home-4 padding-t">
					<div class="container">
						<div class="row">
				        <!--start-categry-area-->
                        <div class="col-lg-3 col-md-3">
                            <div class="category-main-wrap home-4 hidden-sm hidden-xs">
                                <div class="category-title"><h3>Categorias</h3></div>
                                    <div class="cat-single-wrap">
                                        <ul class="nav">
                                            <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lefcate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="<?php echo e($lefcate->idcategoria); ?>" href="javascript:void(0);"><?php echo e($lefcate->nombre); ?></a>
                                                    <div class="single-wrap tablet">
                                                        <div class="cat-wrap">
                                                            <ul class="nav">
                                                                <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($familia->idcategoria == $lefcate->idcategoria): ?>
                                                                        <li><a href="familia/<?php echo e(trim($familia->idfamilia)); ?>"><?php echo e($familia->nombre_familia); ?></a></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!--end-category-area-->
						
                
					<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                    <div class="latest-content text-center">
                        <div class="section-heading">
                            <h3><span class="h-color">Productos</span> Nuevos</h3>
                          
                        </div>
                    </div>
                    <div class="row">
                        
                        <div class="featured-carousel2 indicator">
                            <?php $__currentLoopData = $proNuevos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemNuevo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <!-- Start-single-product -->
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="single-product">
                                    
                                    
                                        <div class="product-img-wrap"> 
                                            <?php if(file_exists("assets/productos/".trim($itemNuevo->idproducto).".jpg")): ?>
                                                <a class="product-img" href="single/<?php echo e(trim($itemNuevo->idproducto)); ?>"> <img src="/assets/productos/<?php echo e(trim($itemNuevo->idproducto)); ?>.jpg" alt="product-image" /></a>
                                            <?php else: ?>
                                                
                                                <a class="product-img" href="single/<?php echo e(trim($itemNuevo->idproducto)); ?>"> <img src="/assets/productos/SINIMAGEN.jpg" alt="product-image" /></a>
                                            <?php endif; ?>
                                            
                                            <div class="add-to-link"> 
                                                <a href="#">
                                                    <div><i class="fa fa-heart"></i><span>Añadir a Deseos</span></div>
                                                </a>
                                                <a data-toggle="modal" data-code="<?php echo e(trim($itemNuevo->idproducto)); ?>" class="vista-modal" data-target="#productModal" href="#">
                                                    <div><i class="fa fa-eye"></i><span>Vista Rápida</span></div>
                                                </a>
                                                
                                            </div>
                                            <div class="add-to-cart">
                                                <a href="#" title="add to cart" class="add-carrito" data-id="<?php echo e(trim($itemNuevo->idproducto)); ?>">
                                                    <div><i class="fa fa-shopping-cart"></i><span>Añadir</span></div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="product-info text-center">
                                            <div class="product-content">
                                                <a href="#"><h3 class="pro-name"><?php echo e($itemNuevo->descripcion); ?></h3></a>
                                                <div class="pro-rating">
                                                    <ul>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star"></i></li>
                                                        <li class="r-grey"><i class="fa fa-star-half-o"></i></li>
                                                    </ul>
                                                </div>
                                                <div class="pro-price">
                                                    <span class="price-text">Precio:</span>
                                                    <span class="normal-price">$<?php echo e($itemNuevo->$precioAc); ?></span>
                                                    <span class="old-price"><del>$<?php echo e($itemNuevo->$precioAc); ?></del></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End-single-product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
					</div>
					</div>
                </div>
            </div>
            <!--End-latest-products-wrap-->
            <?php echo $__env->make('banners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <!-- Start-featured-area-->
            <?php echo $__env->make('destacados', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <!--End-featured-area-->
            <!--Satar-business-policy-wrap-->
            <div class="business-policy-wrap padding-t">
                <div class="container">
                    <div class="row">
                       <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap banner-r-b text-center">
                                <span><i class="fa fa-plane"></i></span>
                                <h4><?php echo e($texto->where('seccion','Servicio1')->first()->contenido); ?></h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                        <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap banner-r-b text-center">
                                <span><i class="fa fa-life-ring"></i></span>
                                <h4><?php echo e($texto->where('seccion','Servicio2')->first()->contenido); ?></h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                        <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap banner-r-b text-center">
                                <span><i class="fa fa-money"></i></span>
                                <h4><?php echo e($texto->where('seccion','Servicio3')->first()->contenido); ?></h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                        <!--Satar-single-p-wrap-->
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="single-p-wrap text-center">
                                <span><i class="fa fa-clock-o"></i></span>
                                <h4><?php echo e($texto->where('seccion','Servicio4')->first()->contenido); ?></h4>
                            </div>
                        </div>
                        <!--end-single-p-wrap-->
                    </div>
                </div>
            </div>
            <!--End-business-policy-wrap-->
            <!--Start-banner-area-->
            <div class="banner-area padding-t home-4 banner-dis">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                            <div class="single-banner banner-r-b">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/'.$imagen['bannerL'])); ?>" /></a>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                            <div class="single-banner">
                                <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/'.$imagen['bannerL2'])); ?>" /></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End-banner-area-->
            <div class="clear"></div>
             <!--Start-top-catagories-wrap-->
            
            <!--End-top-categories-wrap-->
            <!--Start-latest-testimonials-->    
            <div class="latest-testimonial-wrap home-4">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                            <!--start-testimonial-heading-->
                            <div class="testimonial-heading home-4">
                                <div class="section-heading">
                                    <h3><span class="h-color">Últimos</span> Testimonios</h3>
                                </div>
                            </div>
                            <!--End-testimonial-heading-->
                        </div>
                    </div>
                </div>
                <div class="main-testimonial home-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="testimonial-carousel indicator">
                                    <!--single-testimonial-start-->
                                    <div class="single-testimonial">
                                        <div class="testimonial-img">
                                            <p><img src="<?php echo e(asset('assets/themebasic/images/testimonial/'.$imagen['testi1'])); ?>" alt=""></p>
                                        </div>
                                        <div class="testimonial-des home-1">
                                            <p><?php echo e($texto->where('seccion','Testimonio1')->first()->contenido); ?></p>
                                        </div>
                                        <div class="testimonial-author">
                                            <h5><?php echo e($texto->where('seccion','TestimonioAutor1')->first()->contenido); ?></h5>
                                        </div>
                                    </div>
                                    <!--single-testimonial-end-->
                                    <!--single-testimonial-start-->
                                    <div class="single-testimonial">
                                        <div class="testimonial-img">
                                            <p><img src="<?php echo e(asset('assets/themebasic/images/testimonial/'.$imagen['testi2'])); ?>" alt=""></p>
                                        </div>
                                        <div class="testimonial-des">
                                            <p><?php echo e($texto->where('seccion','Testimonio2')->first()->contenido); ?></p>
                                        </div>
                                        <div class="testimonial-author">
                                            <h5><?php echo e($texto->where('seccion','TestimonioAutor2')->first()->contenido); ?></h5>
                                        </div>
                                    </div>
                                    <!--single-testimonial-end-->
                                    <!--single-testimonial-start-->
                                    <div class="single-testimonial">
                                        <div class="testimonial-img">
                                            <p><img src="<?php echo e(asset('assets/themebasic/images/testimonial/'.$imagen['testi3'])); ?>" alt=""></p>
                                        </div>
                                        <div class="testimonial-des">
                                            <p><?php echo e($texto->where('seccion','Testimonio3')->first()->contenido); ?></p>
                                        </div>
                                        <div class="testimonial-author">
                                            <h5><?php echo e($texto->where('seccion','TestimonioAutor3')->first()->contenido); ?></h5>
                                        </div>
                                    </div>
                                    <!--single-testimonial-end-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
            <!--End-latest-testimonials-->
            <!--Start-variety-products-wrap-->
            
            <!--End-variety-products-wrap-->
            <!--Start-newsletter-wrap-->
            
            <!--End-newsletter-wrap-->
            <!--Start-footer-wrap-->
          <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--End-footer-wrap-->
             
        </div>
        <!--End-main-wrapper-->
        <!-- Quickview-product-strat -->
        <?php echo $__env->make('modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End quickview product -->

        <?php echo $__env->make('js-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
		<!-- all js here -->
		
    </body>
</html>     <?php /**PATH C:\laragon\www\surtioffice\resources\views/layout.blade.php ENDPATH**/ ?>