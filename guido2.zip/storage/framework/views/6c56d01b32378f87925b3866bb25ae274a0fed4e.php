<!-- Start-banner-area-->
<div class="banner-area padding-t home-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                    <div class="single-banner banner-m-b">
                        <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/'.$imagen['baner1'])); ?>" /></a>
                    </div>
                    <div class="single-banner banner-r-b">
                        <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/'.$imagen['baner2'])); ?>" /></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="single-banner banner-r-b">
                        <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/'.$imagen['baner3'])); ?>" /></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <div class="single-banner four">
                        <a href="#"><img alt="Hi Guys" src="<?php echo e(asset('assets/themebasic/images/banner/'.$imagen['baner4'])); ?>" /></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End-banner-area--><?php /**PATH C:\laragon\www\guido\resources\views/banners.blade.php ENDPATH**/ ?>