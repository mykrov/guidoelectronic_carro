<?php $__env->startComponent('mail::message'); ?>

# Gracias por preferirnos.

Pedido Numero: <?php echo e($venta->idventas); ?>


#Detalle:

<table class="table" style="width:100%;  align:center;">
    <tr>
        <thead>
            <td style="width:30%">Producto</td>
            <td style="width:20%">Cantidad</td>
            <td style="width:20%">Precio</td>
            <td style="width:10%">IVA</td>
            <td style="width:10%">Total</td>
        </thead>
        <tbody>
            <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item['nombre']); ?></td>
                <td>x <?php echo e($item['cantidad']); ?></td>
                <td>$<?php echo e(round($item['precio'],2)); ?></td>
                <td><?php echo e($item['gr_iva']); ?></td>
                <td>$<?php echo e(round(((floatval($item['precio'])*floatval($item['cantidad']))*0.12)+floatval($item['precio'])*floatval($item['cantidad']),2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </tr>
</table>

<br>
Total: $<?php echo e($venta->total); ?>.<br>
IVA: $<?php echo e($venta->iva); ?>.<br>
Fecha:<?php echo e($venta->fecha); ?>.<br> 

<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\guido\resources\views/email/pedido.blade.php ENDPATH**/ ?>