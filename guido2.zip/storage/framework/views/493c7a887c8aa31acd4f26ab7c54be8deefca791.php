<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('head-meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!-- Add your site or application content here -->
        <!--Start-Preloader-area-->
        <div class="preloader">
            <div class="loading-center">
                <div class="loading-center-absolute">
                    <div class="object object_one"></div>
                    <div class="object object_two"></div>
                    <div class="object object_three"></div>
                </div>
            </div>
        </div>
        <!--end-Preloader-area-->
        <!--header-area-start-->
        <!--Start-main-wrapper-->
        <div class="page-4">
            <!--Start-Header-area-->
            <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--End-Header-area-->
            <!--start-single-heading-banner-->
            <div class="single-banner-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                            <div class="single-ban-top-content">
                                <p>Checkout</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end-single-heading-banner-->
            <!--start-single-heading-->
            <div class="signle-heading">
                <div class="container">
                    <div class="row">
                        <!--start-shop-head -->
                        <div class="col-lg-12">
                            <div class="shop-head-menu">
                                <ul>
                                <li><i class="fa fa-home"></i><a class="shop-home" href="<?php echo e(route('index')); ?>"><span>Inicio</span></a><span><i class="fa fa-angle-right"></i></span></li>
                                    <li class="shop-pro">Checkout</li>
                                </ul>
                            </div>
                        </div>
                        <!--end-shop-head-->
                    </div>
                </div>
            </div>
            <!--end-single-heading-->
            <!-- coupon-area start -->
            <div class="coupon-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="coupon-accordion">
                                <!-- ACCORDION START -->
                                <h3>Es usted cliente? <span id="showlogin">Click aquí para Iniciar Sesión</span></h3>
                                <div id="checkout-login" class="coupon-content">
                                    <div class="coupon-info">
                                        <p class="coupon-text">Al inciar sesión, usted podrá rastrear su pedido facilmente y mantener un registro de todas sus comprar.</p>
                                        <form action="#" data-toggle="validator" role="form">
                                            <p class="form-row-first">
                                                <label>Email <span class="required">*</span></label>
                                                <input type="email" required />
                                            </p>
                                            <p class="form-row-last">
                                                <label>Contraseña  <span class="required">*</span></label>
                                                <input type="password" required />
                                            </p>
                                            <p class="form-row">					
                                                <input type="submit" value="Iniciar Sesión" />
                                                <label>
                                                    <input type="checkbox" />
                                                     Recuerdame
                                                </label>
                                            </p>
                                            <p class="lost-password">
                                                <a href="#">¿Ha olvidado su contraseña?</a>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                                <!-- ACCORDION END -->						
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- coupon-area end -->		
            <!-- checkout-area start -->
            <div class="checkout-area">
                <div class="container">
                    <div class="row">
                        <form action="#">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="checkbox-form">						
                                    <h3>Detalles de facturación</h3>
                                    <div class="row">
									<form data-toggle="validator" role="form">
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Nombre <span class="required">*</span></label>										
                                            <input type="text" placeholder="" value="<?php echo e($user->nombre); ?>" required/>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Apellido <span class="required">*</span></label>										
                                                <input type="text" placeholder=""  value="<?php echo e($user->apellido); ?>"required />
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Nombre de Empresa</label>
                                                <input type="text" placeholder=""  value="<?php echo e($user->empresa); ?>" required />
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Dirección <span class="required">*</span></label>
                                                <input type="text" placeholder="Calle y sector"  value="<?php echo e($user->direccion); ?>" required />
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="checkout-form-list">									
                                                <input type="text" placeholder="Apartamento, Oficina, referencias de locales"  value="<?php echo e($user->referencia); ?>" (Opcional) />
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="country-select">
                                                <label>País <span class="required">*</span></label>
                                                <select>
                                                  <option value="ecuador">Ecuador</option>
                                                  <option value="colombia">Colombia</option>
                                                  <option value="peru">Perú</option>
                                                  <option value="brasil">Brasil</option>
                                                  <option value="venezuela">Venezuela</option>
                                                  <option value="bolivia">Bolivia</option>
                                                  <option value="europa">Europa</option>
                                                  <option value="usa">USA</option>
                                                </select> 										
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Ciudad <span class="required">*</span></label>
                                                <input type="text" placeholder="Ciudad"  value="<?php echo e($user->ciudad); ?>"required />
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Código Postal <span class="required">*</span></label>										
                                                <input type="text" placeholder="Código Postal"  value="<?php echo e($user->codigo_postal); ?>" pattern="^[0-9]{1,}$" required />
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Celular 1 <span class="required">*</span></label>										
                                                <input type="text" placeholder=""  value="<?php echo e($user->celular1); ?>" pattern="^[0-9]{1,}$" required />
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Correo Electrónico <span class="required">*</span></label>										
                                                <input type="email"  value="<?php echo e($user->correo); ?>"placeholder="" required />
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="checkout-form-list">
                                                <label>Celular 2 </label>										
                                                <input type="text" placeholder=""  value="<?php echo e($user->celular2); ?>" pattern="^[0-9]{1,}$"  />
                                            </div>
                                        </div>
                                        
										
                                    </div>
                                    <div class="different-address">
                                            <div class="ship-different-title">
                                                <h3>
													<input id="ship-box" type="checkbox" />
                                                    <label>¿Enviar a otra dirección el pedido?</label>
                                                </h3>
                                            </div>
                                        <div id="ship-box-info" class="row">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
												<div class="checkout-form-list">
													<label>Nombre <span class="required">*</span></label>										
													<input type="text" placeholder=""  required/>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
												<div class="checkout-form-list">
													<label>Apellido <span class="required">*</span></label>										
													<input type="text" placeholder="" required />
												</div>
											</div>
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<div class="checkout-form-list">
													<label>Dirección <span class="required">*</span></label>
													<input type="text" placeholder="Calle y sector" required />
												</div>
											</div>
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<div class="checkout-form-list">									
													<input type="text" placeholder="Apartamento, Oficina, referencias de locales (Opcional)" />
												</div>
											</div>
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<div class="country-select">
													<label>País <span class="required">*</span></label>
													<select>
													  <option value="ecuador">Ecuador</option>
													  <option value="colombia">Colombia</option>
													  <option value="peru">Perú</option>
													  <option value="brasil">Brasil</option>
													  <option value="venezuela">Venezuela</option>
													  <option value="bolivia">Bolivia</option>
													  <option value="europa">Europa</option>
													  <option value="usa">USA</option>
													</select> 										
												</div>
											</div>
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<div class="checkout-form-list">
													<label>Ciudad <span class="required">*</span></label>
													<input type="text" placeholder="Ciudad" required />
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
												<div class="checkout-form-list">
													<label>Código Postal <span class="required">*</span></label>										
													<input type="text" placeholder="Código Postal" pattern="^[0-9]{1,}$" required />
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
												<div class="checkout-form-list">
													<label>Celular 1 <span class="required">*</span></label>										
													<input type="text" placeholder="" pattern="^[0-9]{1,}$" required />
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
												<div class="checkout-form-list">
													<label>Correo Electrónico <span class="required">*</span></label>										
													<input type="email" placeholder="" required />
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
												<div class="checkout-form-list">
													<label>Celular 2 </label>										
													<input type="text" placeholder="" pattern="^[0-9]{1,}$"  />
												</div>
											</div>							
                                        </div>
                                        <div class="order-notes">
                                            <div class="checkout-form-list">
                                                <label>Nota al transportista del pedido</label>
                                                <textarea id="checkout-mess" cols="30" rows="10" placeholder="Notas especiales para la entrega." ></textarea>
                                            </div>									
                                        </div>
                                    </div>													
                                </div>
                            </div>	
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="your-order">
                                    <h3>Orden</h3>
                                    <div class="your-order-table table-responsive">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th class="product-name">Producto</th>
                                                    <th class="product-total">Total</th>
                                                </tr>							
                                            </thead>
                                            <tbody>
                                                <?php if(!is_null(Session::get('carro'))): ?>
                                                <?php $__currentLoopData = Session::get('carro'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="cart_item">
                                                        <td class="product-name">
                                                            <?php echo e($item['nombre']); ?> <strong class="product-quantity"> × <?php echo e($item['cantidad']); ?></strong>
                                                        </td>
                                                        <td class="product-total">
                                                        <span class="amount">$<?php echo e(round($item['precio'],2)); ?></span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <?php
                                                if (!is_null(Session::get('carro'))) {
                                                    $subtotal = 0.0;
                                                    $total2 = 0.0;
                                                    $iva = 0.0;
                                                    foreach(Session::get('carro') as $itemC){
                                                        $itemSub = round(floatval($itemC['precio'])*floatval($itemC['cantidad']),2); 
                                                        $subtotal += $itemSub;
                                                        if($itemC['gr_iva'] == 'S'){
                                                            $iva += round((floatval($itemC['precio'])*floatval($itemC['cantidad']))*0.12,2);
                                                        }
                                                    }
                                                } else {
                                                    $subtotal = 0.0;
                                                    $total = 0.0;
                                                    $iva = 0.0;
                                                }
                                                ?>
                                                <tr class="cart-subtotal">
                                                    <th>Subtotal</th>
                                                <td><span class="amount">$<?php echo e($subtotal); ?></span></td>
                                                </tr>
                                                <tr class="cart-subtotal">
                                                    <th>IVA 12%</th>
                                                    <td><span class="amount">$<?php echo e($iva); ?></span></td>
                                                </tr>
                                                <tr class="shipping">
                                                    <th>Envío</th>
                                                    <td>
                                                        <h5>Acordar con Vendedor</h5>
                                                        
                                                    </td>
                                                </tr>
                                                <tr class="order-total">
                                                    <th>Orden Total</th>
                                                    <td><strong><span class="amount">$<?php echo e($subtotal+$iva); ?></span></strong>
                                                    </td>
                                                </tr>								
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="payment-method">
                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                          <div class="panel panel-default">
                                            <div class="panel-heading" role="tab" id="headingOne">
                                              <h4 class="panel-title">
                                                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                  Transferencia Bancaria Directa
                                                </a>
                                              </h4>
                                            </div>
                                            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                              <div class="panel-body">
                                                <p>Haga su pago directamente en nuestra cuenta bancaria. Utilice su ID de pedido como referencia de pago. Su pedido se enviará cuando los fondos se hayan hecho efectivo en nuestra cuenta.</p>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="panel panel-default">
                                            <div class="panel-heading" role="tab" id="headingTwo">
                                              <h4 class="panel-title">
                                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                  Pago con Cheque
                                                </a>
                                              </h4>
                                            </div>
                                            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                              <div class="panel-body">
                                                 <p>Por favor, envie su cheque a nombre de "SurtiOffice SA". Su pedido se enviará cuando los fondos se hayan hecho efectivo en nuestra cuenta.</p>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="panel panel-default">
                                            <div class="panel-heading" role="tab" id="headingThree">
                                              <h4 class="panel-title">
                                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                  Tarjeta de Crédito o Débito (A través de PAYPAL)
                                                </a>
                                              </h4>
                                            </div>
                                            <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                              <div class="panel-body">
                                                <p>Pague con PayPal; Puede pagar con su tarjeta de crédito si no tiene una cuenta de PayPal.</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>								
                                        <div class="order-button-payment">
                                            <input id="realizar-pedido" type="submit" value="Realizar Pedido" />
                                        </div>
                                    </div>
									</form>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- checkout-area end -->
            <!--Start-footer-wrap-->
            <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--End-footer-wrap-->
             
        </div>
        <!--End-main-wrapper-->
        
        <?php echo $__env->make('js-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
    </body>
</html>     <?php /**PATH C:\laragon\www\guido\resources\views/checkout.blade.php ENDPATH**/ ?>