
<!--Start-Header-area-->
<header>
    <div class="header-top-wrap home-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="header-top-left">
                        <!--Start-Header-language-->
                        <div class="dropdown top-language-wrap"> <a role="button" data-toggle="dropdown" data-target="#" class="top-language dropdown-toggle" href="#"> <img src="<?php echo e(asset('assets/themebasic/images/flag/es.png')); ?>" alt="language"> Español <span class="caret"></span> </a>
                            <ul class="dropdown-menu" role="menu">
                                <li role="presentation"><a role="menuitem" href="#"><img src="<?php echo e(asset('assets/themebasic/images/flag/es.png')); ?>" alt="language"> Español </a></li>
                                
                            </ul>
                        </div>
                        <!--End-Header-language-->
                        <!--Start-Header-currency-->
                        <div class="dropdown top-currency-wrap"> <a role="button" data-toggle="dropdown" data-target="#" class="top-currency dropdown-toggle" href="#"><span class="usd-icon"><i class="fa fa-usd"></i></span> USD <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li role="presentation"><a role="menuitem" href="#"> $ - Dolar Americano</a></li>
                                
                            </ul>
                        </div>
                        <!--End-Header-currency-->
                        <!--Start-welcome-message-->
                        <div class="welcome-mg hidden-xs"><span>Bienvenidos!</span></div>
                        <!--End-welcome-message--> 
                    </div>
                </div>
                <!-- Start-Header-links -->
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="header-top-right">
                        <div class="top-link-wrap">
                            <div class="single-link">
                                <?php if(Session::get('usuario-nombre') == '' or null): ?>
                                
                                <?php else: ?>
                                <div class="my-account"><a href="<?php echo e(route('cuenta')); ?>"><span class=""><?php echo e(Session::get('usuario-nombre')); ?></span></a></div>    
                                <?php endif; ?>
                                
                                <div class="check"><a href="<?php echo e(route('checkout')); ?>"><span class="">Checkout</span></a></div>
                                <?php if(Session::get('usuario-nombre') == '' or null): ?>
                                <div class="login"><a href="<?php echo e(route('login')); ?>"><span  class="">Iniciar Sesión</span></a></div>
                                <?php else: ?>
                                <div class="login"><a href="<?php echo e(route('logout')); ?>"><span  class="">Cerrar Sesión</span></a></div>    
                                <?php endif; ?>

                            </div>
                        </div>
                        
                    </div>

                </div>
                    <!-- End-Header-links -->
            </div>
        </div>
    </div>
    <!--Start-header-mid-area-->
    <div class="header-mid-wrap home-4">
        <div class="container">
            <div class="header-mid-content">
                <div class="row">
                    <!--Start-logo-area-->
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="header-logo">
                            
                            <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('assets/themebasic/images/logo/'.$imagen['logo1'])); ?>" alt="Mt-Shop"></a>
                           
                        </div>
                    </div>
                    <!--End-logo-area-->
                    <!--Start-gategory-searchbox-->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div id="search-category-wrap">
                            <form class="header-search-box" action="/search" method="POST">
                                <div class="search-cat">
                                    <?php echo e(csrf_field()); ?>

                                    <select class="category-items" name="category">
                                        <option value="TODAS">Todas</option>
                                        <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e(trim($cate->idcategoria)); ?>"><?php echo e($cate->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <input type="search" placeholder="Buscar aquí..." id="text-search" name="text">
                                <button id="btn-search-category" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                    <!--End-gategory-searchbox-->
                    <!--Start-cart-wrap-->    
                
                    <?php
                    if (\Session::has('usuario-tipo')) {
                        $tipo = \Session::get('usuario-tipo');

                        if (trim($tipo) == 'CTB') {
                            $precioAc = 'precio2';
                        } elseif (trim($tipo) == 'CTC') {
                            $precioAc = 'precio3';
                        }elseif (trim($tipo) == 'CTD') {
                            $precioAc = 'precio4';
                        }elseif (trim($tipo) == 'CTE') {
                            $precioAc = 'precio5';
                        }elseif (trim($tipo) == 'CTA'){
                            $precioAc = 'precio';
                        }
                    } else {
                        $precioAc='precio';
                    }
                    ?>  
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" id="carro-div">
                        <ul class="header-cart-wrap">
                            <li>
                                <?php if(Session::has('carro')): ?>
                                    <a class="cart" href="#"><?php echo e(count(Session::get('carro'))); ?> Items</a>
                                    <div class="mini-cart-content">
                                        <?php
                                            $subtotal = 0.0
                                        ?>
                                        <div class="cart-products-list scrollOn">
                                            <?php $__currentLoopData = Session::get('carro'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proCarrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="sing-cart-pro">
                                                <div class="cart-image">
                                                    <?php if(file_exists("assets/productos/".trim($proCarrito['item']).".jpg")): ?>
                                                    <a href="#"><img src="<?php echo e(asset('assets/productos/'.$proCarrito['item'].'.jpg')); ?>" alt=""></a>
                                                    <?php else: ?>
                                                    <a href="#"><img src="<?php echo e(asset('assets/productos/SINIMAGEN.jpg')); ?>" alt=""></a>  
                                                    <?php endif; ?>
                                                    
                                                </div>
                                                <div class="cart-product-info">
                                                    <a href="#" class="product-name"><?php echo e($proCarrito['nombre']); ?> </a>
                                                    <div class="cart-price">
                                                        <span class="quantity"><strong> <?php echo e($proCarrito['cantidad']); ?></strong></span>
                                                        <span class="p-price">x $<?php echo e(round($proCarrito['precio'],2)); ?></span>
                                                    </div>
                                                    <a class="edit-pro" title="edit"><i class="fa fa-pencil-square-o"></i></a>
                                                    <a class="remove-pro" data-code=<?php echo e($proCarrito['item']); ?> title="remove"><i class="fa fa-times"></i></a>
                                                </div>
                                            </div>
                                            <?php
                                                $subtotal += floatval($proCarrito['precio'])
                                            ?>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="cart-price-list">
                                            <p class="price-amount">
                                                <span class="cart-subtotal">SUBTotal :</span><span>$<?php echo e(round($subtotal,2)); ?></span>
                                            </p>
                                            <div class="cart-checkout">
                                                <a class="vaciar-carro" href="javascript:void(0)">Vaciar Carro</a>
                                            </div>
                                            <div class="view-cart">
                                            <a href="<?php echo e(route('carro')); ?>">Ver Orden</a>
                                            </div>
                                            
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <a class="cart" href="#">0 items</a>
                                    
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                    <!--End-cart-wrap-->
                </div>
            </div>    
        </div>
    </div>
    
    <!--End-header-mid-area-->
    <!--Start-Mainmenu-area -->
    <div class="mainmenu-area home-4 hidden-sm hidden-xs">
        <div id="sticker"> 
            <div class="container">
                <div class="row">   
                    <div class="col-lg-12 col-md-12 hidden-sm hidden-xs">
                    <div class="log-small"><a class="logo" href="<?php echo e(route('index')); ?>"><img alt="Mt-Shop" src="<?php echo e(asset('assets/themebasic/images/logo/'.$imagen['logo2_nav'])); ?>"></a></div>
                        <div class="mainmenu home-4">
                            <nav>
                                <ul id="nav">
                                    <li ><a href="<?php echo e(route('index')); ?>">Inicio</a>
                                    </li>
                                    <li><a href="<?php echo e(route('nosotros')); ?>">Quienes Somos</a></li>
                                <li><a href="<?php echo e(route('cuenta')); ?>">Mi Cuenta</a></li>
                                    <li class="angle-down"><a href="#">Categorias</a>
                                        <ul class="sub-menu">
                                                <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a class="<?php echo e($cate->idcategoria); ?>" href="<?php echo e(route('categoria-search',trim($cate->idcategoria))); ?>"><?php echo e($cate->nombre); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                    
                                    <li><a href="how-buy.html">Como Comprar</a></li>
                                <li><a href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                                </ul>
                            </nav>
                        </div>        
                    </div>
                </div>
            </div>
        </div>      
    </div>
    <!--End-Mainmenu-area-->
    <!--Start-Mobile-Menu-Area -->
    <div class="mobile-menu-area visible-sm visible-xs">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul>
                                <li ><a href="index.html">Inicio</a>
                                </li>
                                <li><a href="about-us.html">Quienes Somos</a></li>
                                <li><a href="my-account.html">Mi Cuenta</a></li>
                                <li><a href="#">Categorias</a>
                                    <ul>
                                        <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a class="<?php echo e($cate->idcategoria); ?>" href="<?php echo e(route('categoria-search',$cate->idcategoria)); ?>"><?php echo e($cate->nombre); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <li><a href="wishlist.html">Mis Deseos</a></li>
                                <li><a href="how-buy.html">Como Comprar</a></li>
                                <li><a href="contact-us.html">Contacto</a></li>
                            </ul>
                        </nav>
                    </div>					
                </div>
            </div>
        </div>
    </div>
    <!--End-Mobile-Menu-Area -->
</header>
<!--End-Header-area--><?php /**PATH C:\laragon\www\surtioffice\resources\views/header.blade.php ENDPATH**/ ?>