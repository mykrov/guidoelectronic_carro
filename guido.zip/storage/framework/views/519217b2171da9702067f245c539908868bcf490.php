<!-- jquery latest version -->
<script src="<?php echo e(asset('assets/themebasic/js/vendor/jquery-1.12.0.min.js')); ?>"></script>
<!-- bootstrap js -->
<script src="<?php echo e(asset('assets/themebasic/js/bootstrap.min.js')); ?>"></script>
<!-- owl.carousel js -->
<script src="<?php echo e(asset('assets/themebasic/js/owl.carousel.min.js')); ?>"></script>
<!-- meanmenu.js -->
<script src="<?php echo e(asset('assets/themebasic/js/jquery.meanmenu.js')); ?>"></script>
<!-- nivo.slider.js -->
<script src="<?php echo e(asset('assets/themebasic/lib/js/jquery.nivo.slider.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/themebasic/lib/home.js')); ?>" type="text/javascript"></script>
<!-- jquery-ui js -->
<script src="<?php echo e(asset('assets/themebasic/js/jquery-ui.min.js')); ?>"></script>
<!-- scrollUp.min.js -->
<script src="<?php echo e(asset('assets/themebasic/js/jquery.scrollUp.min.js')); ?>"></script>
<!-- jquery.parallax.js -->
<script src="<?php echo e(asset('assets/themebasic/js/jquery.parallax.js')); ?>"></script>
<!-- sticky.js -->
<script src="<?php echo e(asset('assets/themebasic/js/jquery.sticky.js')); ?>"></script>
<!-- jquery.simpleGallery.min.js -->
<script src="<?php echo e(asset('assets/themebasic/js/jquery.simpleGallery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/themebasic/js/jquery.simpleLens.min.js')); ?>"></script>
<!-- countdown.min.js -->
<script src="<?php echo e(asset('assets/themebasic/js/jquery.countdown.min.js')); ?>"></script>
<!-- wow js -->
<script src="<?php echo e(asset('assets/themebasic/js/wow.min.js')); ?>"></script>
<!-- plugins js -->
<script src="<?php echo e(asset('assets/themebasic/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('assets/themebasic/js/toastr.js')); ?>"></script>
<!-- main js -->
<script src="<?php echo e(asset('assets/themebasic/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/themebasic/js/sweetalert.min.js')); ?>"></script>
<?php /**PATH C:\laragon\www\surtioffice\resources\views/js-end.blade.php ENDPATH**/ ?>