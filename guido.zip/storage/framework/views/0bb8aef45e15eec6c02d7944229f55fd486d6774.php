<?php $__env->startComponent('mail::message'); ?>

# Solicitud de Recuperacion de Contraseña.

#De click en el Siguiente enlace para cambio de contraseña:

<?php $__env->startComponent('mail::button', ['url' => $link]); ?>
Cambio de Contraseña
<?php echo $__env->renderComponent(); ?>
 
<br>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\surtioffice\resources\views/mails/recuperar.blade.php ENDPATH**/ ?>